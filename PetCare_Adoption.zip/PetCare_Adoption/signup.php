<?php
session_start();
$conn = new mysqli("localhost", "root", "", "pet_adoption"); // Use the correct database name

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form data is received
if (isset($_POST['first_name'], $_POST['last_name'], $_POST['email'], $_POST['password'])) {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Secure password hashing


    

    // Check if the email already exists
    $check_query = "SELECT id FROM users WHERE email = ?";
    $stmt = $conn->prepare($check_query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        echo "<script>alert('Account already exists with this email. Please log in.'); window.location.href='login.html';</script>";
        exit();
    }

    $stmt->close();

    // Insert new user data
    $sql = "INSERT INTO users (first_name, last_name, email, password) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $first_name, $last_name, $email, $password);

    if ($stmt->execute()) {
        echo "<script>alert('Registration successful! Redirecting to login page.'); window.location.href='login.html';</script>";
        exit();
    } else {
        echo "<script>alert('Error during registration. Please try again later.'); window.location.href='signup.html';</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('All fields are required.'); window.location.href='signup.html';</script>";
}

$conn->close();
?>

<?php
session_start();
$conn = new mysqli("localhost", "root", "", "pet_adoption");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    if (password_verify($password, $row['password'])) {
        $_SESSION['user'] = $row['email'];
        echo "Login successful! <a href='dashboard.php'>Go to Dashboard</a>";
    } else {
        echo "Invalid password. <a href='login.html'>Try again</a>";
    }
} else {
    echo "No account found. <a href='signup.html'>Sign up</a>";
}

$stmt->close();
$conn->close();
?>